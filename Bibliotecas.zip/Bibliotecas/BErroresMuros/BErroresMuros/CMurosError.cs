﻿using System.Collections.Generic;

namespace B_Procesar_Info
{
    public class CMurosError
    {
        public string Piername { get; set; }
        public string Story { get; set; }
        public List<string> Mensaje { get; set; } = new List<string>();

        public override string ToString()
        {
            string Texto = "";

            for (int i = 0; i < Mensaje.Count; i++)
            {
                if (i == Mensaje.Count - 1)
                {
                    Texto += Mensaje[i];
                }
                else
                {
                    Texto += Mensaje[i] + " y ";
                }
            }

            return string.Format(Texto);
        }
    }
}