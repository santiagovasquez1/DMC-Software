﻿using System;
using System.Collections.Generic;

namespace B_Procesar_Info
{
    public class CProcesar
    {
        public  List<CMurosError> Muros_errores { get; set; } = new List<CMurosError>();

        public void Set_errores_muros(string Pier, string Story, double RhoL, float Bw, double Lebe_Izq, double Lebe_Der, double Pmax, double Pc)
        {
            string Mensaje = "";
            CMurosError muroError;

            if (RhoL >= 0.0066 & Bw < 15 || Lebe_Izq > 0 & Bw < 15 || Lebe_Der > 0 & Bw < 15 || Pmax > Pc)
            {
                muroError = new CMurosError
                {
                    Piername = Pier,
                    Story = Story
                };

                if (RhoL >= 0.0066 & Bw < 15)
                {
                    Mensaje = "Bw < 0.15m y Rho_l>=0.0066";
                    muroError.Mensaje.Add(Mensaje);
                }

                if (Lebe_Izq > 0 & Bw < 15 || Lebe_Der > 0 & Bw < 15)
                {
                    Mensaje = "Bw<0.15m y Ebe>0";
                    muroError.Mensaje.Add(Mensaje);
                }

                if (Pmax > Pc)
                {
                    Mensaje = $"La carga de {Math.Round(Pmax, 2)} es mayor que {Math.Round(Pc, 2)}";
                    muroError.Mensaje.Add(Mensaje);
                }

                Muros_errores.Add(muroError);
            }
        }
    }
}